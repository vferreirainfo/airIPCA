To translate this plugin into your language, please make a copy of vertikal_plugin.pot then rename it into your language file like this:

vertikal_plugin-de_DE.po
vertikal_plugin-fr_FR.po

...