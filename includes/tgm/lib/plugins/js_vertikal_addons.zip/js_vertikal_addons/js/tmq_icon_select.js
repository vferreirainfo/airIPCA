jQuery(function($) {
	$('.iconslist').find('ul:eq(0)').fadeIn();
	$('.tabs-heading').find('a').on('click', function(e) {
		e.preventDefault();
		var active_tab = $(this);
		$('.tabs-heading a').removeClass('selected');
		active_tab.addClass('selected');
		$('.iconslist ul').hide();
		$('.iconslist ul').each( function() {
			if ( $(this).attr('data-page')  == active_tab.attr('id') ) {
				$(this).fadeIn();
			}
		})
	});
	$('.iconslist').find('li').on('click', function(e) {
		e.preventDefault();
		var active_icon = $(this);
		var icon_class = active_icon.find('i').attr('class');
		var icon_class_name = icon_class.replace('fa ', '');
		$('.icon-zoom i').removeClass();
		$('.icon-zoom i').addClass(icon_class);
		$('.icon-name').text(icon_class_name);
		$('.tmq-icon-container input').val(icon_class_name);
	});
});