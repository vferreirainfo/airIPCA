jQuery(function($) {
	$('.blog_category_selector').find('select').on('change', function() {
		var selected_deps = [];
		$('.blog_category_selector').find('select :selected').each(function (i, selected) {
			selected_deps[i] = $(selected).val();
		});
		var blog_cat_values = selected_deps.join(',');
		$('.blog_category_selector').find('input').val(blog_cat_values);
	});
});